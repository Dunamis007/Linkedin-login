// Replace this line at the top of your script.js file
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwq0WB7teMsH-78aT1aFUUNJw1YjfTfn7jURGh-edWbFui89C5ZnlZgKLCjUSMo6c_E/exec';

// Add these utility functions at the top of script.js
function setCookie(name, value, days) {
    const expires = new Date();
    expires.setTime(expires.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`;
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function deleteCookie(name) {
    document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/`;
}

// Add session verification on page load
async function verifySession() {
    const sessionToken = getCookie('sessionToken');
    if (sessionToken) {
        try {
            const response = await fetch(SCRIPT_URL, {
                method: 'POST',
                body: JSON.stringify({
                    action: 'verifySession',
                    sessionToken: sessionToken
                })
            });

            const result = await response.json();
            if (result.status === 'success') {
                // Session is valid, redirect to dashboard or update UI
                showLoggedInState(result.email);
            } else {
                // Session is invalid, clear cookies
                deleteCookie('sessionToken');
                showLoggedOutState();
            }
        } catch (error) {
            console.error('Session verification failed:', error);
            showLoggedOutState();
        }
    }
}

// Modify the login form submission handler
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const statusDiv = document.getElementById('login-status');

    try {
        const response = await fetch(SCRIPT_URL, {
            method: 'POST',
            body: JSON.stringify({
                action: 'login',
                email: email,
                password: password
            })
        });

        const result = await response.json();
        statusDiv.textContent = result.message;
        statusDiv.className = 'status-message ' + (result.status === 'success' ? 'success' : 'error');
        
        if (result.status === 'success') {
            // Store session token in cookie
            setCookie('sessionToken', result.sessionToken, 1); // 1 day
            showLoggedInState(email);
        }
    } catch (error) {
        statusDiv.textContent = 'An error occurred. Please try again.';
        statusDiv.className = 'status-message error';
    }
});

// Add logout functionality
function logout() {
    const sessionToken = getCookie('sessionToken');
    if (sessionToken) {
        fetch(SCRIPT_URL, {
            method: 'POST',
            body: JSON.stringify({
                action: 'logout',
                sessionToken: sessionToken
            })
        }).finally(() => {
            deleteCookie('sessionToken');
            showLoggedOutState();
        });
    }
}

// UI state management functions
function showLoggedInState(email) {
    document.querySelector('.container').innerHTML = `
        <header>
            <img src="images/linkedin-logo.png" alt="LinkedIn" class="logo">
            <div class="user-info">
                <span>Welcome, ${email}</span>
                <button onclick="logout()" class="logout-btn">Logout</button>
            </div>
        </header>
        <main class="dashboard">
            <h1>Welcome to Your Dashboard</h1>
            <!-- Add your dashboard content here -->
        </main>
    `;
}

function showLoggedOutState() {
    window.location.reload();
}

// Call verifySession when page loads
document.addEventListener('DOMContentLoaded', verifySession); 